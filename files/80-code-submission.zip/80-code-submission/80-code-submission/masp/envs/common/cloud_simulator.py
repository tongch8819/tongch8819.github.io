from masp.envs.common.logx import get_logger

import numpy as np

class CSEnv:

    def __init__(self, 
        log_file_path = None, 
    ):

        if log_file_path is not None:
            self.logger = get_logger(log_file_path)

        self.env_name = "Abstract Cloud Simulator"

    def __str__(self):
        res =  f"=== Cloud Simulator Env ===\n"
        res +=  f"env_name: {self.env_name}\n"
        res += f"H0: {self.h0}\nREW: {self.reward_f.__name__}\n"
        res += f"UD: {self.is_dynamic}\n#U: {self.num_users}\n"
        res += f"==========================="
        return res

    def step(self, action_arr, is_random_policy=False):
        """
        Input:
        - action_arr: action with numpy.array dtype
        """
        action = self.a_codec.decode_numpy(action_arr)

        # transition into next state
        next_s, is_overflow = self.trans_p.eval(self.cur_state, action)
        # compute reward
        reward, r_comps = self.reward_f(self.cur_state, action)
        # build infos
        infos = {
            'r_comps' : r_comps,
            'is_overflow' : is_overflow,
        }
        done = False

        next_s_arr = self.s_codec.encode_pre_transform(next_s)

        self.cur_state = next_s
        self.action_space.cur_o = next_s
        self.cur_action = action
        return next_s_arr, reward, done, infos

    def close(self):
        pass

    def seed(self, seed):
        self.seed = seed
        np.random.seed(seed)

    
        

