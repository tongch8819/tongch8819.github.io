from masp.envs.common.subscriber import Subscriber
import numpy as np

class DoubleSubscriber(Subscriber):

    def send_signal(self):
        """
        Sample the new request signal from a parametrized gamma distribution.
        Return an integer signal.

        Output:
        - signal number: 
            - if s > 0, ask for quota; 
            - s = 0, no action; 
            - s < 0, give back quota;

        When deploy is correlated with signal, signal could not depend on 
        deploy anymore.
        """

        def gen_request():
            shape, scale = self.config['request'][1:]
            n = int(np.random.gamma(shape, scale, size=1))  # return a np.ndarray
            return n

        def gen_recycle():
            shape, scale = self.config['recycle'][1:]
            n = int(np.random.gamma(shape, scale, size=1))
            n = max(-n, -self.cur_quota)
            return n 
        dist_F = self.get_dist(keyword='request')
        signal_type = np.random.random()
        if signal_type <= dist_F[0]:
            new_signal = gen_request()
        elif signal_type <= dist_F[1]:
            new_signal = 0
        else:
            new_signal = gen_recycle()
      
        self.cur_signal = new_signal
        # update signal history
        self.signal_hist.append(new_signal)
        return new_signal

    def adjust_deploy(self):
        """
        Adjust deployment number of virtual machine.
        """
        dist_F = self.get_dist(keyword='deploy')

        signal_type = np.random.random()
        # n means delta deploy
        # upper bound: current quota - current deploy
        # lower bound: -current deploy
        if signal_type <= dist_F[0]:
            shape, scale = self.config['deploy'][1:]
            n = int(np.random.gamma(shape, scale, size=1))
            delta_deploy = n
        elif signal_type <= dist_F[1]:
            delta_deploy = 0
        else:
            shape, scale = self.config['release'][1:]
            n = int(np.random.gamma(shape, scale, size=1))
            delta_deploy = -n

        # return intention to affect request signal
        expected_delta_deploy = delta_deploy

        # cur_quota_physi <= cur_quota
        delta_deploy_ub = self.cur_quota_physi - self.deploy_vm_num
        if delta_deploy > delta_deploy_ub:
            # bad allocation plan
            self.confined_hist.append(True)
        else:
            self.confined_hist.append(False)

        # intrinsic range
        delta_deploy = min(delta_deploy, delta_deploy_ub)
        delta_deploy = max(delta_deploy, -self.deploy_vm_num)

        self.delta_deploy_hist.append(delta_deploy)
        self.deploy_vm_num += delta_deploy 
        self.deploy_hist.append(self.deploy_vm_num)
        return expected_delta_deploy


class GreedySubscriberComplex(DoubleSubscriber):

    def gen_signal(self):
        """
        Sample the new request signal from a parametrized gamma distribution.
        Return an integer signal.

        Output:
        - signal number: 
            - if s > 0, ask for quota; 
            - s = 0, no action; 
            - s < 0, give back quota;

        When deploy is correlated with signal, signal could not depend on 
        deploy anymore.
        """
        def gen_request():
            shape, scale = self.config['request'][1:]
            n = int(np.random.gamma(shape, scale, size=1))  # return a np.ndarray
            return n

        def gen_recycle():
            shape, scale = self.config['recycle'][1:]
            n = int(np.random.gamma(shape, scale, size=1))
            n = max(-n, -self.cur_quota)
            return n 
        dist_F = self.get_dist(keyword='request')
        signal_type = np.random.random()
        if signal_type <= dist_F[0]:
            new_signal = gen_request()
        elif signal_type <= dist_F[1]:
            new_signal = 0
        else:
            new_signal = gen_recycle()
 
        self.cur_signal = new_signal
        # update signal history
        self.signal_hist.append(new_signal)
        return new_signal

    def send_signal(self):
        if len(self.signal_hist) == 0:
            return self.gen_signal()
        else:
            return self.signal_hist[-1]

    def gen_deploy(self):
        dist_F = self.get_dist(keyword='deploy')

        signal_type = np.random.random()
        # n means delta deploy
        # upper bound: current quota - current deploy
        # lower bound: -current deploy
        if signal_type <= dist_F[0]:
            shape, scale = self.config['deploy'][1:]
            n = int(np.random.gamma(shape, scale, size=1))
            delta_deploy = n
        elif signal_type <= dist_F[1]:
            delta_deploy = 0
        else:
            shape, scale = self.config['release'][1:]
            n = int(np.random.gamma(shape, scale, size=1))
            delta_deploy = -n

        self.delta_deploy = delta_deploy
        return delta_deploy

    def adjust_deploy(self):
        """
        Adjust deployment number of virtual machine.
        """
        delta_deploy = self.delta_deploy
        # return intention to affect request signal
        expected_delta_deploy = delta_deploy

        # cur_quota_physi <= cur_quota
        delta_deploy_ub = self.cur_quota_physi - self.deploy_vm_num
        if delta_deploy > delta_deploy_ub:
            # bad allocation plan
            self.confined_hist.append(True)
        else:
            self.confined_hist.append(False)

        # intrinsic range
        delta_deploy = min(delta_deploy, delta_deploy_ub)
        delta_deploy = max(delta_deploy, -self.deploy_vm_num)

        self.delta_deploy_hist.append(delta_deploy)
        self.deploy_vm_num += delta_deploy 
        self.deploy_hist.append(self.deploy_vm_num)
        return expected_delta_deploy





