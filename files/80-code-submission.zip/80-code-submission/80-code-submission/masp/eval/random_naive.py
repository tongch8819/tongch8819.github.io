from masp.eval.core import total_steps
from masp.eval.sa_eval import get_system_dr
from masp.envs import NaiveCSEnv, NaiveCSEnvComplex
from masp.eval.metrics import get_oaf

import torch
import numpy as np
import argparse

def run_one_round(seed, models, verbose=False):
    return _run_one_round_core(seed=seed, env=NaiveCSEnv(), verbose=verbose, fixed=False)

def run_one_round_complex(seed, models, verbose=False):
    return _run_one_round_core(seed=seed, env=NaiveCSEnvComplex(), verbose=verbose, fixed=False)

def _run_one_round_core(seed, env, verbose=False, fixed=False):
    torch.manual_seed(seed)
    np.random.seed(seed)
    cache = dict()

    dr_hist = []
    o, d, ep_ret, ep_len = env.reset(), False, 0, 0
    act_n = env.action_space.shape[0]
    for i in range(total_steps):
        if fixed:
            a = np.ones(shape=(act_n, )) 
        else:
            a = env.action_space.sample()

        o, r, d, info = env.step(a)
        if verbose:
            print("Request: ", env.cur_state.request_vec)
            dep_vec = env.cur_state.deploy_vec
            dep_total = dep_vec.sum()
            print("Deploy: ", dep_vec, dep_vec.sum())
            allo_vec = env.cur_state.allocated_vec
            allo_total = allo_vec.sum()
            print("Allocated: ", allo_vec, allo_total)
            physi_allo_vec = [ user.cur_quota_physi for _, user in env.user_pool.items()]
            print("Physical Allo: ", physi_allo_vec, sum(physi_allo_vec))
            w = env.cur_state.physical_resource
            print("Ava, Phy, ActFactor: ", env.cur_state.available_quota, 
                w,  allo_total / w )
            print("Action: ", a)
            print("Dep: ", dep_total / w)
            print()
        ep_ret += r
        ep_len += 1

        dr = get_system_dr(env.cur_state)
        dr_hist.append(dr)

    oaf = get_oaf(env.user_pool).mean()
    avg_dr = sum(dr_hist) / len(dr_hist)
    if verbose:
        print(f"Seed: {seed}   AVG-DR: {avg_dr:.2%}   OAF: {oaf}")
    cache['avg_dr'] = avg_dr
    cache['saf'] = oaf
    cache['ep_ret'] = ep_ret 
    return cache, dr_hist

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int, default=1)
    parser.add_argument('--verbose', '-v', action='count', help='')
    args = parser.parse_args()

    cache, _ = run_one_round(args.seed, models=None, verbose=args.verbose)
    print(cache)

if __name__ == "__main__":
    main()