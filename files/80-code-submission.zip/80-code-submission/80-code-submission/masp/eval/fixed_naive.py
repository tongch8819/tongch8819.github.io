from masp.eval.random_naive import _run_one_round_core
from masp.envs import NaiveCSEnv, NaiveCSEnvComplex

import argparse

def run_one_round(seed, models, verbose=False):
    return _run_one_round_core(seed=seed, env=NaiveCSEnv(), verbose=verbose, fixed=True)

def run_one_round_complex(seed, models, verbose=False):
    return _run_one_round_core(seed=seed, env=NaiveCSEnvComplex(), verbose=verbose, fixed=True)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int, default=1)
    parser.add_argument('--verbose', '-v', action='count', help='')
    args = parser.parse_args()

    cache, _ = run_one_round_complex(args.seed, models=None, verbose=args.verbose)
    print(cache)

if __name__ == "__main__":
    main()