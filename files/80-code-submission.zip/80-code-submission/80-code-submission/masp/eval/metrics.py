import numpy as np
import pandas as pd

def get_system_dr(user_pool, total_vm_cores):
    data = []
    for name, user in user_pool.items():
        t = user.deploy_hist
        data.append(t)
    res = np.array(data).sum(axis=0) / total_vm_cores
    return res

def remove_nan(arr):
    mask = np.logical_not(np.isnan(arr))
    return arr[mask]

def dist_l2(x, y):
    t = x - y
    res = (t * t).sum()
    return res

def get_l2_dist(user_pool):
    name_to_l2dist = dict()
    for name, user in user_pool.items():
        sr = user.get_sr()  # sr's length is 1 less than dr's
        dr = user.get_dr()
        z = dist_l2(sr, dr[1:])
        name_to_l2dist[name] = z
    res = np.array(list(name_to_l2dist.values()))
    return res

def allocation_fairness(data, ascending=True):
    core_df = pd.DataFrame(data, 
        columns=['sr', 'cre', 'dep']).rank(
            method='max', na_option='bottom', ascending=ascending)
    a = (core_df['sr'] - core_df['cre']).abs().sum()
    b = (core_df['sr'] - core_df['dep']).abs().sum()
    return a + b

def get_oaf(user_pool):
    mat_3d = get_mat_3d(user_pool)
    oaf = []
    for i in range(mat_3d.shape[1]):
        oaf.append(allocation_fairness(mat_3d[:, i, :]))
    return np.array(oaf)

def get_iaf(user_pool):
    mat_3d = get_mat_3d(user_pool)
    iaf = [] 
    for i in range(mat_3d.shape[0]):
        iaf.append(allocation_fairness(mat_3d[i, :, :]))
    return np.array(iaf)

def get_mat_3d(user_pool):
    """
    - user
    - time
    - attribute
    """
    mat_3d = []
    for name, user in user_pool.items():
        d, q = user.deploy_hist[:-1], user.quota_hist[:-1]
        su, si = user.supply_hist, user.signal_hist[:-1]
        c = user.credit_hist[:-1]
        sr = np.array(su) / (np.array(si) + 1e-4)
        dep = np.array(d) / (np.array(q) + 1e-4)
        mat_3d.append(np.array([sr, c, dep]).T)
    return np.array(mat_3d)
    
def get_act_std(a_hist, mode='Time'):
    data = np.array(a_hist)
    axis = 1 if mode == 'Time' else 0
    res = data.std(axis=axis)
    return res

def remove_outliers(data):
    x = pd.Series(data)
    small_x = x[x.between(x.quantile(.05), x.quantile(.95))] # without outliers
    removed_num = len(x) - len(small_x)
    if removed_num > 0:
        print(f"Remove {removed_num} outliers")
    return small_x.values