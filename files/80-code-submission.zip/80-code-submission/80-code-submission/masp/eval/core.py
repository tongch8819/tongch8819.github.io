import os.path as osp
import os
import torch

total_steps = 400
seed = 1
num_of_seeds = 5

def load_single_model(exp_home_dir):
    """Return dict."""
    model_path = osp.join(exp_home_dir, 'pyt_save/model.pt')
    model = torch.load(model_path)
    return dict(naive=model)

def load_double_model(exp_home_dir):
    factor_modelpath = osp.join(exp_home_dir, 'factor/pyt_save/model.pt')
    allocation_modelpath = osp.join(exp_home_dir, 'allocation/pyt_save/model.pt')
    factor_model = torch.load(factor_modelpath)
    allocation_model = torch.load(allocation_modelpath)
    return dict(allocation=allocation_model, factor=factor_model)

def load_ma_model(exp_home_dir):
    factor_modelpath = osp.join(exp_home_dir, 'factor/pyt_save/model.pt')
    factor_model = torch.load(factor_modelpath)
    cache = dict(factor=factor_model)
    for name in os.listdir(exp_home_dir):
        if name[:2] != 'al':
            continue
        allocation_modelpath = osp.join(exp_home_dir, f'{name}/pyt_save/model.pt')
        allocation_model = torch.load(allocation_modelpath)
        cache[name] = allocation_model
    return cache 

def load_double_model_by_epoch(exp_home_dir, epoch=None):
    if epoch is None:
        # search for most recent epoch
        max_epoch = None
        for name in os.listdir(osp.join(exp_home_dir, 'factor/pyt_save')):
            epoch = int(name.split('.')[0][5:])
            if max_epoch is None or epoch > max_epoch:
                max_epoch = epoch
        epoch = max_epoch
        
    factor_modelpath = osp.join(exp_home_dir, f'factor/pyt_save/model{epoch}.pt')
    allocation_modelpath = osp.join(exp_home_dir, f'allocation/pyt_save/model{epoch}.pt')
    factor_model = torch.load(factor_modelpath)
    allocation_model = torch.load(allocation_modelpath)
    return dict(allocation=allocation_model, factor=factor_model)