from masp.eval.core import total_steps, seed, load_ma_model
from masp.envs import PrimaryCSEnv, SecondaryCSEnv
from masp.envs.common.reward_function import naive_reward, naive_reward_oaf
from masp.eval.metrics import get_oaf

import numpy as np
import torch
import argparse
import sys
import os.path as osp
import pandas as pd


def get_action(o, bundle):
    ac = bundle['ac']
    return ac.act(torch.as_tensor(o, dtype=torch.float32))

def get_system_dr(state):
    return state.deploy_vec.sum() / state.physical_resource[0]

def run_one_round(
    seed,
    models,
    verbose=False,
    print_action=False,
    dump_data_path='data',
    save_action_hist=None,
    ):
    """
    Given a random seed, generate one trajectory by sdsac
    """
    torch.manual_seed(seed)
    np.random.seed(seed)
    factor_ac = models['factor']

    kwargs = dict(
        seed=seed,
        verbose=verbose,
        print_action=print_action,
        dump_data_path=dump_data_path
    )

    env = PrimaryCSEnv()
    num_aux_mdp = env.num_users
    bundle = dict(env=env, ac=factor_ac)
    sub_bundles = []
    for i in range(num_aux_mdp):
        sub_bundle = dict(env=SecondaryCSEnv(), ac=models[f'allocation-{i}'])
        sub_bundles.append(sub_bundle)
    sub_ep_rets = [0] * num_aux_mdp
    sub_ep_lens = [0] * num_aux_mdp

    cache = dict()
    dr_hist = []
    o, ep_ret, ep_len = bundle['env'].reset(), 0, 0
    a = get_action(o, bundle)  # a means relax factor
    sub_o_lst = bundle['env'].split_observation(a)
    for i in range(num_aux_mdp):
        sub_ep_rets[i], sub_ep_lens[i] = 0, 0
    # Main loop: collect experience in env and update/log each epoch
    env = bundle['env']
    a_hist = []
    ep_ret_phony = 0.0
    for t in range(total_steps):
        
        # Until start_steps have elapsed, randomly sample actions
        # from a uniform distribution for better exploration. Afterwards, 
        # use the learned policy (with some noise, via act_noise). 
        sub_a_lst, sub_r_lst = [], []
        for i, sub_o in enumerate(sub_o_lst):
            sub_a = get_action(sub_o, sub_bundle)
            # sub_a[0] = min(sub_a[0] + 0.8, 1.)
            sub_r, _ = sub_bundles[i]['env'].reward_f(
                sub_bundles[i]['env'].s_codec.decode_numpy(sub_o), 
                sub_bundles[i]['env'].a_codec.decode_numpy(sub_a)
            )
            sub_a_lst.append(sub_a[0])
            sub_r_lst.append(sub_r)
            sub_ep_rets[i] += sub_r
            sub_ep_lens[i] += 1
        sub_a_lst = list(np.clip(np.array(sub_a_lst) * 5, a_max=1.0, a_min=None))

        # pass satisfaction ratio into state of primary mdp
        bundle['env'].cur_state.satisfaction_ratio = np.array(sub_a_lst)
        # update o - the numpy representation of current state of primary mdp
        o = bundle['env'].s_codec.encode_numpy(bundle['env'].cur_state)
        # Step the env
        a = get_action(o, bundle)  # a means relax factor
        a_hist.append(np.array(sub_a_lst + [a[0]]))
        if kwargs['print_action']:
            sys.stderr.write(','.join(list(map(str, sub_a_lst + [a[0]]))) + '\n')
        o2, r, d, info = bundle['env'].step(a)

        ep_ret += r
        ep_len += 1
        sub_o2_lst = bundle['env'].split_observation(a)
        ep_ret_phony += naive_reward_oaf(bundle['env'].cur_state, None)[0]  # return r, r_comps

        if kwargs['verbose']:
            print("Request: ", env.cur_state.request_vec)
            dep_vec = env.cur_state.deploy_vec
            dep_total = dep_vec.sum()
            print("Deploy: ", dep_vec, dep_vec.sum())
            allo_vec = env.cur_state.allocated_vec
            allo_total = allo_vec.sum()
            print("Allocated: ", allo_vec, allo_total)
            tt = np.array([x.cur_quota_physi for _, x in bundle['env'].user_pool.items()])
            print("Physical Quota:", tt, tt.sum())
            w = env.cur_state.physical_resource
            print("Ava, Phy, ActFactor: ", env.cur_state.available_quota, 
                w,  allo_total / w )
            print("Allocation: ", sub_a_lst, "Factor: ", a)
            print("Dep: ", dep_total / w)
            print()

        current_dr = get_system_dr(env.cur_state)
        # should be equal length for different seeds
        dr_hist.append(current_dr)
        # Super critical, easy to overlook step: make sure to update 
        # most recent observation!
        o = o2
        sub_o_lst = sub_o2_lst
    oaf  = get_oaf(bundle['env'].user_pool).mean()
    avg_dr = sum(dr_hist) / len(dr_hist)
    if kwargs['verbose']:
        print(f"EpRet: {ep_ret}   Seed: {seed}   DR: {avg_dr:.2%}   OAF: {oaf}")
    cache['avg_dr'] = avg_dr
    cache['saf'] = oaf
    cache['ep_ret'] = ep_ret_phony

    if save_action_hist is not None:
        pd.DataFrame(a_hist).to_csv(save_action_hist)
        print("Please check {} for action history.".format(save_action_hist))
    if dump_data_path:
        for name, user in bundle['env'].user_pool.items():
            user.dump_hist_data(save_path=osp.join(dump_data_path, name + '.csv'))
    return cache, dr_hist


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('log_dir', type=str, help="")
    parser.add_argument('--dump_data_path', type=str, help="", default=None)
    parser.add_argument('--seed', type=int, default=1)
    parser.add_argument('--save_action_hist', type=str, help='Save action history path', default=None)
    parser.add_argument('--verbose', '-v', action='count', help='')
    args = parser.parse_args()

    models = load_ma_model(args.log_dir)
    cache, _ = run_one_round(
        seed=args.seed,
        models=models,
        verbose=args.verbose,
        print_action=False,
        dump_data_path=args.dump_data_path,
        save_action_hist=args.save_action_hist,
    )
    print(cache)


if __name__ == "__main__":
    main()