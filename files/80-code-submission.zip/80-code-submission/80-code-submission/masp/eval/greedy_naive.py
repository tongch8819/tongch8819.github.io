from masp.envs.naive_cs_env_complex import NaiveCSEnvComplex
from masp.eval.core import total_steps
from masp.eval.sa_eval import get_system_dr
from masp.envs import NaiveCSEnvGreedy, NaiveCSEnvGreedyComplex
from masp.eval.metrics import get_oaf

import torch
import numpy as np
import argparse

def onestep_greedy(pre_signals, state, ratio=None, next_d=None): 
    """
    ratio: deploy to request
    """
    next_r = np.array(pre_signals)
    if ratio is None:
        next_d = np.array(next_d)
    else:
        next_d = np.floor(next_r * ratio)

    q = state.allocated_vec
    d = state.deploy_vec
    w = state.physical_resource

    negative_b = 1 * (next_r <= 0.0)
    positive_r = (next_r > 0) * next_r
    # next_d is large, consider it into supply, else ignore the case
    optimal_approved_quota = np.clip(next_d - (q - d), a_max=None, a_min=0)
    positive_b = optimal_approved_quota / (positive_r + 1e-4) 
    b = negative_b + positive_b
    b = np.clip(b, a_max=1.0, a_min=0.0)
    optimal_quota_sum = (next_d + d).sum()
    C = min((optimal_quota_sum / w)[0], 1)  # make sure the C has no dimension
    C = np.array([C])

    return np.concatenate([b, C]) 

def get_action_single_user(env):
    pre_signals = []
    for _, user in env.user_pool.items():
        pre_signals.append(user.send_signal())
    env.trans_p.pre_signals = pre_signals
    a = onestep_greedy(pre_signals, env.cur_state, ratio=user.ratio_of_deploy)
    return a

def get_action_double_user(env):
    pre_signals, pre_delta_deploy = [], []
    for _, user in env.user_pool.items():
        pre_signals.append(user.gen_signal())
        pre_delta_deploy.append(user.gen_deploy())
    env.trans_p.pre_signals = pre_signals
    a = onestep_greedy(pre_signals, env.cur_state, next_d=pre_delta_deploy)
    return a

def run_one_round(seed, models, verbose=False):
    torch.manual_seed(seed)
    np.random.seed(seed)
    cache = dict()

    env = NaiveCSEnvGreedyComplex()

    dr_hist = []
    o, d, ep_ret, ep_len = env.reset(), False, 0, 0
    for i in range(total_steps):
        a = get_action_double_user(env)

        o, r, d, info = env.step(a)
        dr = get_system_dr(env.cur_state)
        dr_hist.append(dr)
        ep_ret += r
        ep_len += 1
        if verbose:
            print("Request: ", env.cur_state.request_vec)
            dep_vec = env.cur_state.deploy_vec
            dep_total = dep_vec.sum()
            print("Deploy: ", dep_vec, dep_vec.sum())
            allo_vec = env.cur_state.allocated_vec
            allo_total = allo_vec.sum()
            print("Allocated: ", allo_vec, allo_total)
            w = env.cur_state.physical_resource
            tt = np.array([x.cur_quota_physi for _, x in env.user_pool.items()])
            print("Physical Quota:", tt, tt.sum())
            print("Ava, Phy, ActFactor: ", env.cur_state.available_quota, 
                w,  allo_total / w )
            print("Allocation: ", a[:-1], "Factor: ", a[-1])
            print("Dep: ", dep_total / w)
            print()

    oaf = get_oaf(env.user_pool).mean()
    avg_dr = sum(dr_hist) / len(dr_hist)
    if verbose:
        print(f"Seed: {seed}   DR: {dr:.2%}   OAF: {oaf}")
    cache['avg_dr'] = avg_dr 
    cache['saf'] = oaf
    cache['ep_ret'] = ep_ret

    return cache, dr_hist

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int, default=1)
    parser.add_argument('--verbose', '-v', action='count', help='')
    args = parser.parse_args()

    cache, _ = run_one_round(args.seed, models=None, verbose=args.verbose)
    print(cache)

if __name__ == "__main__":
    main()