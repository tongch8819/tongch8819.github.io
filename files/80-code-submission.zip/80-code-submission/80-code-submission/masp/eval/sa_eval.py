from masp.eval.core import total_steps, load_single_model
from masp.envs import NaiveCSEnv, NaiveCSEnvComplex
from masp.eval.metrics import get_oaf

import torch
import argparse
import numpy as np
import pandas as pd
import os.path as osp

def get_action(o, bundle):
    ac = bundle['ac']
    return ac.act(torch.as_tensor(o, dtype=torch.float32))

def get_system_dr(state):
    return state.deploy_vec.sum() / state.physical_resource[0]

def run_one_round(seed, models, verbose=False, save_action_hist=None, dump_data_path=None, **kwargs):
    return _run_one_round_core(env=NaiveCSEnv(),
        seed=seed, models=models, verbose=verbose, 
        save_action_hist=save_action_hist, dump_data_path=dump_data_path, **kwargs
    )

def run_one_round_complex(seed, models, verbose=False, save_action_hist=None, dump_data_path=None, **kwargs):
    return _run_one_round_core(env=NaiveCSEnvComplex(),
        seed=seed, models=models, verbose=verbose, 
        save_action_hist=save_action_hist, dump_data_path=dump_data_path, **kwargs
    )

def _run_one_round_core(env, seed, models, verbose=False, save_action_hist=None, dump_data_path=None, **kwargs):
    torch.manual_seed(seed)
    np.random.seed(seed)
    ac = models['naive']
    bundle = dict(env=env, ac=ac)

    cache = dict()
    dr_hist = []
    a_hist = []
    o, d, ep_ret, ep_len = bundle['env'].reset(), False, 0, 0
    for i in range(total_steps):
        # Take deterministic actions at test time 
        a = get_action(o, bundle)
        if kwargs.get('sensitivity_tpl', None) is not None: 
            sensi = kwargs['sensitivity_tpl']
            a = np.clip(a, a_min=sensi[0], a_max=sensi[1])
        o, r, d, info = bundle['env'].step(a)
        dr = get_system_dr(env.cur_state)
        dr_hist.append(dr)
        a_hist.append(a)
        ep_ret += r
        ep_len += 1
        if verbose is not None:
            if verbose >= 1:
                print("Reward:", r, info['r_comps'])
            if verbose >= 2:
                print("Request: ", env.cur_state.request_vec)
                dep_vec = env.cur_state.deploy_vec
                dep_total = dep_vec.sum()
                print("Deploy: ", dep_vec, dep_vec.sum())
                allo_vec = env.cur_state.allocated_vec
                allo_total = allo_vec.sum()
                print("Allocated: ", allo_vec, allo_total)
                w = env.cur_state.physical_resource
                print("Ava, Phy, ActFactor: ", env.cur_state.available_quota, 
                    w,  allo_total / w )
                print("Allocation: ", a[:-1], "Factor: ", a[-1])
                print("Dep: ", dep_total / w)
                print()


    oaf = get_oaf(env.user_pool).mean()
    avg_dr = sum(dr_hist) / len(dr_hist)
    if verbose:
        print(f"EpRet: {ep_ret}   Seed: {seed}   DR: {dr:.2%}   OAF: {oaf}")
    cache['avg_dr'] = avg_dr 
    cache['saf'] = oaf
    cache['ep_ret'] = ep_ret

    if save_action_hist is not None:
        pd.DataFrame(a_hist).to_csv(save_action_hist)
        print("Please check {} for action history.".format(save_action_hist))
    if dump_data_path:
        for name, user in bundle['env'].user_pool.items():
            user.dump_hist_data(save_path=osp.join(dump_data_path, name + '.csv'))
        print("Please check {} for user trace.".format(dump_data_path))
    return cache, dr_hist

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('log_dir', type=str, help="")
    parser.add_argument('--dump_data_path', type=str, help="", default=None)
    parser.add_argument('--seed', type=int, default=1)
    parser.add_argument('--verbose', '-v', action='count', help='')
    parser.add_argument('--save_action_hist', type=str, help='Save action history path', default=None)
    parser.add_argument('--complex', action='store_true', help='')
    args = parser.parse_args()

    models = load_single_model(args.log_dir)
    if args.complex:
        cache, _ = run_one_round_complex(seed=args.seed, models=models, 
            verbose=args.verbose, save_action_hist=args.save_action_hist, 
            dump_data_path=args.dump_data_path)
    else:
        cache, _ = run_one_round(seed=args.seed, models=models, 
            verbose=args.verbose, save_action_hist=args.save_action_hist, 
            dump_data_path=args.dump_data_path)
    print(cache)

if __name__ == "__main__":
    main()