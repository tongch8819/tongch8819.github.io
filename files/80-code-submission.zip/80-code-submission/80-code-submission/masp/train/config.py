import torch

max_epochs=4000

ac_kwargs = dict(hidden_sizes=[128,128,128], activation=torch.nn.ReLU)

debug_params = dict(
    steps_per_epoch=100, 
    max_ep_len=10,
    update_after=0,
    update_every=25,
)
train_params = dict(
    steps_per_epoch=4000, 
    epochs=500,
    max_ep_len=1000,
    update_after=100,
    update_every=50,
)