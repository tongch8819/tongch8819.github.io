from masp.train.config import ac_kwargs, debug_params, train_params, max_epochs
from masp.envs import PrimaryCSEnv, SecondaryCSEnv 
from masp.algos import masp_ddpg_pytorch 

import argparse

def train(log_dir, pri_scaler, sec_scaler, is_train=False):
    env_fn = lambda : PrimaryCSEnv()
    sub_env_fn = lambda : SecondaryCSEnv()
    exp_name = "MASP-DDPG"
    logger_kwargs = dict(output_dir=log_dir, exp_name=exp_name)
    
    params = train_params if is_train else debug_params
    masp_ddpg_pytorch(
        env_fn=env_fn, 
        sub_env_fn=sub_env_fn,
        ac_kwargs=ac_kwargs, 
        epochs=max_epochs,
        logger_kwargs=logger_kwargs,
        **params,
        pri_scaler=pri_scaler, 
        sec_scaler=sec_scaler, 
    )

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('log_dir', type=str, help="Logging Directory")
    parser.add_argument('--is_train', action='store_true')
    parser.add_argument('--pri_scaler', type=int, help='primary scaler', default=1)
    parser.add_argument('--sec_scaler', type=int, help='secondary scaler', default=1)
    args = parser.parse_args()

    train(args.log_dir, args.pri_scaler, args.sec_scaler, args.is_train)

if __name__ == "__main__":
    main()