from masp.train.config import ac_kwargs, debug_params, train_params, max_epochs
from masp.envs import NaiveCSEnv, NaiveCSEnvComplex
from masp.algos import sac_pytorch 

import argparse

def train(log_dir, is_train, alpha, complex_env=False):
    exp_name = 'SAC'
    if complex_env:
        env_fn = lambda : NaiveCSEnvComplex()
    else:
        env_fn = lambda : NaiveCSEnv()
    logger_kwargs = dict(output_dir=log_dir, exp_name=exp_name)
    params = train_params if is_train else debug_params
    sac_pytorch(
        env_fn=env_fn, ac_kwargs=ac_kwargs, 
        epochs=max_epochs,
        logger_kwargs=logger_kwargs,
        **params,
        alpha=alpha,
    )

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('log_dir', type=str, help="Logging Directory")
    parser.add_argument('--is_train', action='store_true')
    parser.add_argument('--alpha', type=float, help="Entropy Regularization Coefficient", default=0.2)
    parser.add_argument('--is_complex', action='store_true')
    args = parser.parse_args()

    train(args.log_dir, args.is_train, args.alpha, complex_env=args.is_complex)

if __name__ == "__main__":
    main()