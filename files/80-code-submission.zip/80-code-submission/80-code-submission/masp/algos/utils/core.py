import torch.nn as nn

def mlp(sizes, activation, output_activation=nn.Identity):
    layers = []
    for j in range(len(sizes)-1):
        act = activation if j < len(sizes)-2 else output_activation
        lin_layer = nn.Linear(sizes[j], sizes[j+1])
        # lin_layer.weight = nn.Parameter(torch.ones((sizes[j+1], sizes[j])))  # reverse shape in weight
        nn.init.kaiming_normal_(lin_layer.weight, mode='fan_out', nonlinearity='relu')
        layers += [lin_layer, act()]
        # layers += [nn.Linear(sizes[j], sizes[j+1]), act()]
    return nn.Sequential(*layers)