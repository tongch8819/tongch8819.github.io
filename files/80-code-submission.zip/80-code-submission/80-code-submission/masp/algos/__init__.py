from masp.algos.sac.sac import sac as sac_pytorch 
from masp.algos.ddpg.ddpg import ddpg as ddpg_pytorch 

from masp.algos.ma_sac.ma_sac import ma_sac as ma_sac_pytorch
from masp.algos.ma_ddpg.ma_ddpg import ma_ddpg as ma_ddpg_pytorch

from masp.algos.masp_sac.masp_sac import masp_sac as masp_sac_pytorch
from masp.algos.masp_ddpg.masp_ddpg import masp_ddpg as masp_ddpg_pytorch

from masp.algos.masp_sac_ada.masp_sac_ada import masp_sac_ada as masp_sac_ada_pytorch
from masp.algos.masp_ddpg_ada.masp_ddpg_ada import masp_ddpg_ada as masp_ddpg_ada_pytorch