from masp.algos.utils.core import mlp
import numpy as np
import scipy.signal

import torch
import torch.nn as nn

def max_grad(optimizer):
    res = []
    for a in optimizer.param_groups:
        for b in a['params']:
            res.append(b.grad.max())
    res = torch.Tensor(res)
    return res.max()

def combined_shape(length, shape=None):
    if shape is None:
        return (length,)
    return (length, shape) if np.isscalar(shape) else (length, *shape)


def count_vars(module):
    return sum([np.prod(p.shape) for p in module.parameters()])

class MLPActor(nn.Module):

    def __init__(self, obs_dim, act_dim, hidden_sizes, activation, act_limit):
        super().__init__()
        pi_sizes = [obs_dim] + list(hidden_sizes) + [act_dim]
        # self.pi = mlp(pi_sizes, activation, nn.Tanh)
        self.pi = mlp(pi_sizes, activation, nn.Identity)
        self.act_limit = act_limit

    def forward(self, obs):
        return (torch.tanh(self.pi(obs)) + 1) / 2

class MLPQFunction(nn.Module):

    def __init__(self, obs_dim, act_dim, hidden_sizes, activation):
        super().__init__()
        self.q = mlp([obs_dim + act_dim] + list(hidden_sizes) + [1], activation)

    def forward(self, obs, act):
        q = self.q(torch.cat([obs, act], dim=-1))
        return torch.squeeze(q, -1) # Critical to ensure q has right shape.

class MLPActorCritic(nn.Module):

    def __init__(self, obs_dim, act_dim, act_limit, hidden_sizes=(256,256,256),
                 activation=nn.ReLU):
        super().__init__()

        # build policy and value functions
        self.pi = MLPActor(obs_dim, act_dim, hidden_sizes, activation, act_limit)
        self.q = MLPQFunction(obs_dim, act_dim, hidden_sizes, activation)

    def act(self, obs):
        with torch.no_grad():
            return self.pi(obs).numpy()
