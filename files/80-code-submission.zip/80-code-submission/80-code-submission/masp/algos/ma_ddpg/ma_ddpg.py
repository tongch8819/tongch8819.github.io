from copy import deepcopy
import numpy as np
import torch
from torch.optim import Adam
import time
import os.path as osp
import json
import masp.algos.ma_ddpg.core as core
from masp.algos.utils.logx import EpochLogger
from masp.algos.utils.serialization_utils import convert_json


class ReplayBuffer:
    """
    A simple FIFO experience replay buffer for DDPG agents.
    """

    def __init__(self, obs_dim, act_dim, size):
        self.obs_buf = np.zeros(core.combined_shape(size, obs_dim), dtype=np.float32)
        self.obs2_buf = np.zeros(core.combined_shape(size, obs_dim), dtype=np.float32)
        self.act_buf = np.zeros(core.combined_shape(size, act_dim), dtype=np.float32)
        self.rew_buf = np.zeros(size, dtype=np.float32)
        self.done_buf = np.zeros(size, dtype=np.float32)
        self.ptr, self.size, self.max_size = 0, 0, size

    def store(self, obs, act, rew, next_obs, done):
        self.obs_buf[self.ptr] = obs
        self.obs2_buf[self.ptr] = next_obs
        self.act_buf[self.ptr] = act
        self.rew_buf[self.ptr] = rew
        self.done_buf[self.ptr] = done
        self.ptr = (self.ptr+1) % self.max_size
        self.size = min(self.size+1, self.max_size)

    def sample_batch(self, batch_size=32):
        idxs = np.random.randint(0, self.size, size=batch_size)
        batch = dict(obs=self.obs_buf[idxs],
                     obs2=self.obs2_buf[idxs],
                     act=self.act_buf[idxs],
                     rew=self.rew_buf[idxs],
                     done=self.done_buf[idxs])
        return {k: torch.as_tensor(v, dtype=torch.float32) for k,v in batch.items()}



def ma_ddpg(env_fn,
    sub_env_fn,
    actor_critic=core.MLPActorCritic,
    ac_kwargs=dict(),
    seed=3407,
    steps_per_epoch=4000,
    epochs=100,
    replay_size=int(1e6),
    gamma=0.99,
    polyak=0.995,
    pi_lr=1e-2,
    q_lr=1e-2,
    batch_size=100,
    start_steps=10000,
    update_after=1000,
    update_every=50,
    act_noise=0.1,
    num_test_episodes=10,
    max_ep_len=1000,
    logger_kwargs=dict(),
    save_freq=1,
    grad_debug=False,
    pri_scaler=1.0,
    sec_scaler=1.0):

    torch.manual_seed(seed)
    np.random.seed(seed)

    with open(logger_kwargs['output_dir'] + '/train_params.json', 'w') as wrt:
        config_json = convert_json(locals())
        output = json.dumps(config_json, separators=(',',':\t'), indent=4, sort_keys=True)
        wrt.write(output)

    def init_env_ac(env_fn, logger_kwargs):
        logger = EpochLogger(**logger_kwargs)
        logger.save_config(locals())

        env, test_env = env_fn(), env_fn()
        obs_dim = env.observation_space.shape[0]
        act_dim = env.action_space.shape[0]
    
        # Action limit for clamping: critically, assumes all dimensions share the same bound!
        act_limit = env.action_space.high[0]

        # Create actor-critic module and target networks
        ac = actor_critic(obs_dim, act_dim, act_limit, **ac_kwargs)
        ac_targ = deepcopy(ac)
    
        # Freeze target networks with respect to optimizers (only update via polyak averaging)
        for p in ac_targ.parameters():
            p.requires_grad = False
    
        # Experience buffer
        replay_buffer = ReplayBuffer(obs_dim=obs_dim, act_dim=act_dim, size=replay_size)

        # Set up optimizers for policy and q-function
        pi_optimizer = Adam(ac.pi.parameters(), lr=pi_lr)
        q_optimizer = Adam(ac.q.parameters(), lr=q_lr)
    
        # Set up model saving
        logger.setup_pytorch_saver(ac)
    
        # Count variables (protip: try to get a feel for how different size networks behave!)
        var_counts = tuple(core.count_vars(module) for module in [ac.pi, ac.q])
        logger.log('\nNumber of parameters: \t pi: %d, \t q: %d\n'%var_counts)
        bundle = dict(
            logger =logger,
            env = env,
            test_env = test_env, 
            ac = ac, 
            ac_targ = ac_targ, 
            replay_buffer = replay_buffer,
            pi_optimizer = pi_optimizer, 
            q_optimizer = q_optimizer,
            act_dim = act_dim,
            act_limit = act_limit,
        )
        return bundle


    # Set up function for computing DDPG Q-loss
    def compute_loss_q(data, bundle):
        o, a, r, o2, d = data['obs'], data['act'], data['rew'], data['obs2'], data['done']
        ac, ac_targ = bundle['ac'], bundle['ac_targ']

        q = ac.q(o,a)

        # Bellman backup for Q function
        with torch.no_grad():
            q_pi_targ = ac_targ.q(o2, ac_targ.pi(o2))
            backup = r + gamma * (1 - d) * q_pi_targ

        # MSE loss against Bellman backup
        loss_q = ((q - backup)**2).mean()

        # Useful info for logging
        loss_info = dict(QVals=q.detach().numpy())

        return loss_q, loss_info
    

    # Set up function for computing DDPG pi loss
    def compute_loss_pi(data, bundle):
        o = data['obs']
        ac = bundle['ac']

        q_pi = ac.q(o, ac.pi(o))
        return -q_pi.mean()


    def update(bundle):
        # First run one gradient descent step for Q.
        logger = bundle['logger']
        ac, ac_targ = bundle['ac'], bundle['ac_targ']
        q_optimizer, pi_optimizer = bundle['q_optimizer'], bundle['pi_optimizer']
        data = bundle['replay_buffer'].sample_batch(batch_size)

        q_optimizer.zero_grad()
        loss_q, loss_info = compute_loss_q(data, bundle)
        loss_q.backward()
        if grad_debug:
            print("Q loss", loss_q, "Grad", core.max_grad(q_optimizer))
        q_optimizer.step()

        # Freeze Q-network so you don't waste computational effort 
        # computing gradients for it during the policy learning step.
        for p in ac.q.parameters():
            p.requires_grad = False

        # Next run one gradient descent step for pi.
        pi_optimizer.zero_grad()
        loss_pi = compute_loss_pi(data, bundle)
        loss_pi.backward()
        if grad_debug:
            print("Pi loss", loss_pi, "Grad", core.max_grad(pi_optimizer))
        pi_optimizer.step()

        # Unfreeze Q-network so you can optimize it at next DDPG step.
        for p in ac.q.parameters():
            p.requires_grad = True

        # Record things
        logger.store(LossQ=loss_q.item(), LossPi=loss_pi.item(), **loss_info)

        # Finally, update target networks by polyak averaging.
        with torch.no_grad():
            for p, p_targ in zip(ac.parameters(), ac_targ.parameters()):
                # NB: We use an in-place operations "mul_", "add_" to update target
                # params, as opposed to "mul" and "add", which would make new tensors.
                p_targ.data.mul_(polyak)
                p_targ.data.add_((1 - polyak) * p.data)

    def get_action(o, noise_scale, bundle):
        """
        Given a full observation, split it into sub observation 
        """
        ac = bundle['ac']
        act_dim, act_limit = bundle['act_dim'], bundle['act_limit']

        a = ac.act(torch.as_tensor(o, dtype=torch.float32))
        a += noise_scale * np.random.randn(act_dim)
        return a

    def test_agent(bundle):
        test_env = bundle['test_env']
        logger = bundle['logger']

        for j in range(num_test_episodes):
            o, d, ep_ret, ep_len = test_env.reset(), False, 0, 0
            r_comps_dic = dict()
            while not(d or (ep_len == max_ep_len)):
                o, r, d, info = test_env.step(get_action(o, 0, bundle))
                ep_ret += r
                ep_len += 1

                # logging reward sub-components
                if info.get('r_comps', None) is not None:
                    for name, val in info['r_comps'].items():
                        if r_comps_dic.get(name, None) is None:
                            r_comps_dic[name] = val
                        else:
                            r_comps_dic[name] += val
            save_dic = dict(TestEpRet=ep_ret, TestEpLen=ep_len)
            save_dic.update(r_comps_dic)
            logger.store(**save_dic)
            

    def tail_logging(epoch ,bundle):
        logger = bundle['logger']
        env = bundle['env']
        # Save model
        if (epoch % save_freq == 0) or (epoch == epochs):
            logger.save_state({'env': env}, None)

        # Test the performance of the deterministic version of the agent.
        # test_agent(bundle)

        # Log info about epoch
        logger.log_tabular('Env', bundle['env'].env_name)
        logger.log_tabular('Epoch', epoch)
        logger.log_tabular('OriEpRet', with_min_and_max=True)
        logger.log_tabular('EpRet', with_min_and_max=True)
        # logger.log_tabular('TestEpRet', with_min_and_max=True)
        # logger.log_tabular('EpLen', average_only=True)
        # logger.log_tabular('TestEpLen', average_only=True)
        logger.log_tabular('TotalEnvInteracts', t)
        logger.log_tabular('QVals', with_min_and_max=True)
        logger.log_tabular('LossPi', average_only=True)
        logger.log_tabular('LossQ', average_only=True)
        logger.log_tabular('Time', time.time()-start_time)
        logger.dump_tabular()

    def reward_exchange(sub_r_lst, r):
        # primary r has high likelihood to be zero
        # add secondary MDP reward into primary MDP
        mean = sum(sub_r_lst) / len(sub_r_lst) 
        pri_r = r + pri_scaler * mean
        # add primary MDP reward into secondary MDP
        new_sub_r_lst = [ sub_r + sec_scaler * r  for sub_r in sub_r_lst]
        return new_sub_r_lst, pri_r
    

    root_log_dir = logger_kwargs['output_dir']
    logger_kwargs['output_dir'] = osp.join(root_log_dir, 'factor')
    bundle = init_env_ac(env_fn, logger_kwargs)

    num_aux_mdp = bundle['env'].num_users
    sub_bundles = []
    for i in range(num_aux_mdp):
        logger_kwargs['output_dir'] = osp.join(root_log_dir, 'allocation') + '-{}'.format(i)
        sub_bundle = init_env_ac(sub_env_fn, logger_kwargs)
        sub_bundles.append(sub_bundle)
    ori_sub_ep_rets = [0] * num_aux_mdp
    sub_ep_rets = [0] * num_aux_mdp
    sub_ep_lens = [0] * num_aux_mdp

    # Prepare for interaction with environment
    total_steps = steps_per_epoch * epochs
    start_time = time.time()
    o, ori_ep_ret, ep_ret, ep_len = bundle['env'].reset(), 0, 0, 0
    a = get_action(o, act_noise, bundle)  # a means relax factor
    r = 0
    sub_o_lst = bundle['env'].split_observation(a)
    num_of_sub_o = len(sub_o_lst)
    for i, sub_bundle in enumerate(sub_bundles):
        _, ori_sub_ep_rets[i], sub_ep_rets[i], sub_ep_lens[i] = sub_bundle['env'].reset(), 0, 0, 0

    # Main loop: collect experience in env and update/log each epoch
    for t in range(total_steps):
        
        # Until start_steps have elapsed, randomly sample actions
        # from a uniform distribution for better exploration. Afterwards, 
        # use the learned policy (with some noise, via act_noise). 
        sub_a_lst, sub_r_lst = [], []
        for sub_o in sub_o_lst:
            sub_a = get_action(sub_o, act_noise, sub_bundles[i])
            sub_r, _ = sub_bundles[i]['env'].reward_f(
                sub_bundles[i]['env'].s_codec.decode_numpy(sub_o), 
                sub_bundles[i]['env'].a_codec.decode_numpy(sub_a)
            )
            # sub_bundle['env'].cur_state = sub_bundle['env'].s_codec.decode_numpy(sub_o)
            # sub_o2, sub_r, sub_d, _ = sub_bundle['env'].step(sub_a)
            ori_sub_ep_rets[i] += sub_r
            sub_a_lst.append(sub_a[0])
            sub_r_lst.append(sub_r)

        a = get_action(o, act_noise, bundle)  # a means relax factor
        # this is slightly different from dd sac async
        # because the computation of factor does not involve the 
        # information of output of allocation policy
        # padding the full state with the output of allocation policy
        bundle['env'].cur_state.satisfaction_ratio = np.array(sub_a_lst)
        o = bundle['env'].s_codec.encode_numpy(bundle['env'].cur_state)
        o2, r, d, info = bundle['env'].step(a)

        # exchange reward simutaneously
        ori_ep_ret += r
        sub_r_lst, r = reward_exchange(sub_r_lst, r)
        ep_ret += r
        ep_len += 1
        sub_o2_lst = bundle['env'].split_observation(a)
        for sub_o, sub_o2, sub_r, i in zip(sub_o_lst, sub_o2_lst, sub_r_lst, range(num_aux_mdp)):
            sub_d = False
            sub_bundles[i]['replay_buffer'].store(sub_o, sub_a, sub_r, sub_o2, sub_d)
            # delayed update
            sub_ep_rets[i] += sub_r
            sub_ep_lens[i] += 1

        # Ignore the "done" signal if it comes from hitting the time
        # horizon (that is, when it's an artificial terminal signal
        # that isn't based on the agent's state)
        d = False if ep_len==max_ep_len else d

        # Store experience to replay buffer
        bundle['replay_buffer'].store(o, a, r, o2, d)

        # Super critical, easy to overlook step: make sure to update 
        # most recent observation!
        o = o2
        sub_o_lst = sub_o2_lst

        # End of trajectory handling
        if d or (ep_len == max_ep_len):
            bundle['logger'].store(
                OriEpRet=ori_ep_ret, 
                EpRet=ep_ret, 
                EpLen=ep_len
            )
            o, ori_ep_ret, ep_ret, ep_len = bundle['env'].reset(), 0, 0, 0
            for i, sub_bundle in enumerate(sub_bundles):
                sub_bundle['logger'].store(
                    OriEpRet=ori_sub_ep_rets[i], 
                    EpRet=sub_ep_rets[i] / num_of_sub_o, 
                    EpLen=sub_ep_lens[i] / num_of_sub_o
                )
                ori_sub_ep_rets[i], sub_ep_rets[i], sub_ep_lens[i] = 0, 0, 0

        # Update handling
        if t >= update_after and t % update_every == 0:
            for _ in range(update_every):
                update(bundle)
                for sub_bundle in sub_bundles:
                    update(sub_bundle)

        # End of epoch handling
        if (t+1) % steps_per_epoch == 0:
            epoch = (t+1) // steps_per_epoch

            tail_logging(epoch, bundle)
            # no testing stage
            for sub_bundle in sub_bundles:
                tail_logging(epoch, sub_bundle)
