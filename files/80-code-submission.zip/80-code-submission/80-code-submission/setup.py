from setuptools import setup

setup(
   name='masp',
   version='1.0.0',
   description='Multi-Agent Reinforcement Learning with Shared Policy for Cloud Quota Management Problem',
   author='Tong Cheng',
   author_email='v-tongcheng@microsoft.com',
   packages=['masp'],  
   install_requires=[], 
)