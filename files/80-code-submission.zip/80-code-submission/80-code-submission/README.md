# Multi-Agent Reinforcement Learning with Shared Policy for Cloud Quota Management Problem

## Requirements
Install dependencies by creating a conda environment:
```
conda env create -f conda_env.yml
```
After the installation activate your environment with:
```
conda activate masp
```
Install this project as a package `masp`
```
pip install -e .
```


## Instructions
To train a MASP-SAC agent for quota management problem on cloud simulation environment, run:
```
mkdir -p exp/masp_sac
python masp/train/masp_sac.py \
    exp/masp_sac \
    --is_train
```
All the loggings of experiment are going to be stored under directory `exp/masp_sac` and printed through `stdout`.


Likewise, you could also train other agents in a similar way:
```
mkdir -p exp/naive_ddpg
python masp/train/naive_ddpg.py \
    exp/naive_ddpg \
    --is_train

mkdir -p exp/naive_sac
python masp/train/naive_sac.py \
    exp/naive_sac \
    --is_train

mkdir -p exp/ma_ddpg
python masp/train/ma_ddpg.py \
    exp/ma_ddpg \
    --is_train

mkdir -p exp/ma_sac
python masp/train/ma_sac.py \
    exp/ma_sac \
    --is_train

mkdir -p exp/masp_ddpg
python masp/train/masp_ddpg.py \
    exp/masp_ddpg \
    --is_train
```

### Performance Evaluation
To evaluate a MASP-SAC policy on both deployment ratio DR and allocation fairness AF, run:
```
python eval/ma_eval.py exp/masp_sac
```
The results will be printed in the terminal.

Likewise, you could also evaluate other policies in a similar way:
```
python masp/eval/random_naive.py
python masp/eval/fixed_naive.py
python masp/eval/greedy_naive.py
python masp/eval/sa_eval.py exp/naive_ddpg
python masp/eval/sa_eval.py exp/naive_sac
python masp/eval/ma_eval.py exp/ma_ddpg
python masp/eval/ma_eval.py exp/ma_sac
python masp/eval/masp_eval.py exp/masp_ddpg
python masp/eval/masp_eval.py exp/masp_sac
```


### Explore Reward Communication

We could arbitrarily set reward communication hyperparameters $\alpha_1$ and $\alpha_2$ by specifying `pri_scaler` and `sec_scaler`:
```
mkdir -p exp/masp_sac_5_1
python masp/train/masp_sac.py \
    exp/masp_sac_5_1 \
    --is_train \
    --pri_scaler 5 \
    --sec_scaler 1
python masp/eval/masp_eval.py exp/masp_sac_5_1
```
To train a MASP-SAC agent with adaptive weighting method, run
```
mkdir -p exp/masp_sac_ada
python masp/train/masp_sac_ada.py \
    exp/masp_sac_ada \
    --is_train
python masp/eval/masp_eval.py exp/masp_sac_ada
```